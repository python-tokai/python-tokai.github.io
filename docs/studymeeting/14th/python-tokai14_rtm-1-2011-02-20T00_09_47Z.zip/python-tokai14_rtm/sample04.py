#!/usr/bin/env python
# -*- mode: python -*- -*- coding: utf-8 -*-
#
#  sample04.py - write test for rtm api
#
#   Copyright (C) 2011 SAKODA, Sumiya <higebobo@gmail.com>
#

"""\
write test for rtm api
"""

__author__ = "Sumiya Sakoda"
__version__ = "$Revision$"
__date__ = "$Date: 2011/01/31 08:32:13 $"

import os
import sys

from sample01 import API_KEY, SHARED_SECRET, TOKEN, API_URL, FORMAT, \
     DATA_DIR, RTMError, json, get_response

DEBUG = False
LIST_ID = 'your list id'

def test_add_task(name, priority='N', due=None, debug=DEBUG):
    '''add task test'''

    # -*-*-*-  [part 1] create timeline -*-*-*-    
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.timelines.create',
              'perms': 'write',
              'auth_token': TOKEN,
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'timeline.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))

    # parse json
    if response['rsp']['stat'] == 'ok':
        timeline = response['rsp']['timeline']
    else:
        raise RTMError('Failed to create timeline')

    # -*-*-*-  [part 2] add basic task -*-*-*-    
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.tasks.add',
              'perms': 'delete',
              'auth_token': TOKEN,
              'timeline': timeline,
              'list_id': LIST_ID,
              'name': name,
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'taskadd.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))
    
    # parse json
    if response['rsp']['stat'] == 'ok':
        taskseries = response['rsp']['list']['taskseries']
        taskseries_id = taskseries['id']
        task_id = taskseries['task']['id']
    else:
        raise RTMError('Failed to create timeline')

    # -*-*-*-  [part 3] set priority -*-*-*- 
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.tasks.setPriority',
              'perms': 'delete',
              'auth_token': TOKEN,
              'timeline': timeline,
              'list_id': LIST_ID,
              'taskseries_id': taskseries_id,
              'task_id': task_id,
              'priority': priority,
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'tasksetpriority.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))

    print response

    # -*-*-*-  [part 4] set due -*-*-*-
    if not due:
        return
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.tasks.setDueDate',
              'perms': 'delete',
              'auth_token': TOKEN,
              'timeline': timeline,
              'list_id': LIST_ID,
              'taskseries_id': taskseries_id,
              'task_id': task_id,
              'due': due,
              'has_due_time': '1',
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'tasksetdue.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))

    print response
    
def main():
    name = 'Happy New Year party'
    priority = '1'
    due = '2012-01-01T00:00:00+09:00'
    test_add_task(name, priority, due)

if __name__ == "__main__":
    main()

#!/usr/bin/env python
#
#  sample03.py - read test for rtm api
#
#   Copyright (C) 2011 SAKODA, Sumiya <higebobo@gmail.com>
#

"""\
read test for rtm api
"""

__author__ = "Sumiya Sakoda"
__version__ = "$Revision$"
__date__ = "$Date: 2011/01/31 08:32:13 $"

import os
import sys

from sample01 import API_KEY, SHARED_SECRET, TOKEN, API_URL, FORMAT, \
     DATA_DIR, RTMError, json, get_response

DEBUG = False

def test_list(debug=DEBUG):
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.lists.getList',
              'perms': 'read',
              'auth_token': TOKEN,
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'list.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))

    print response

    # parse json and return result
    if response['rsp']['stat'] == 'ok':
        print '-' * 20
        print 'My list for RTM'
        print '-' * 20
        for l in response['rsp']['lists']['list']:
            try:
                print '* %s - %s' % (l['id'], l['name'].encode('utf-8'))
            except:
                print '* %s - %s' % (l['id'], l['name'])
    else:
        raise RTMError('Failed to get response')

def test_location(debug=DEBUG):
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.locations.getList',
              'perms': 'read',
              'auth_token': TOKEN,
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'location.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))

    print response

    # parse json and return result
    if response['rsp']['stat'] == 'ok':
        print '-' * 20
        print 'My location for RTM'
        print '-' * 20
        for l in response['rsp']['locations']['location'][:10]:
            print '* ', l['name'].encode('utf-8')
    else:
        raise RTMError('Failed to get response')

def test_task(debug=DEBUG):
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.tasks.getList',
              'perms': 'read',
              'auth_token': TOKEN,
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'task.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))

    print response

    # parse json and return result
    if response['rsp']['stat'] == 'ok':
        print '-' * 20
        print 'My task for RTM'
        print '-' * 20
        for x in response['rsp']['tasks']['list']:
            if not x.has_key('taskseries'):
                continue
            for y in x['taskseries'][:2]:
                name = y['name']
                task = y['task']
                try:
                    print '*', name.encode('utf-8')
                    print '  - [priority]', task['priority']
                    print '  - [due]', task['due']
                except:
                    pass
    else:
        raise RTMError('Failed to get response')
    
def main():
    test_list()

if __name__ == "__main__":
    if len(sys.argv) >= 2:
        arg = sys.argv[1]
        if arg == 'list':
            test_list()
        elif arg == 'location':
            test_location()
        elif arg == 'task':
            test_task()
        else:
            main()
    else:
        main()

.. -*- mode: rst -*- coding: utf-8 -*-

:Id: $Id$
:Date: $Date::                           $

.. contents::


============================================
Remember The MilkのAPIを弄るのサンプルコード
============================================

全般の注意
==========

* 使用に際しては自己責任でお願いします
* ソースはUNIX改行コード、UTF-8です
* Python2.4以上で動作しますが、必要に応じて外部ライブラリが要ります(simplejson他)
* ソースのDEBUGをTrueにするとオフラインでのテストになりますがモックデータは各自で用意してください
* 具体的な使い方はソースのmainメソッドをご覧下さい

下準備
======

* Rmember The Milkのユーザ登録をする

  http://www.rememberthemilk.com/

* API KEYを得る

  http://www.rememberthemilk.com/services/api/keys.rtm

* sample01.pyの以下の項目をご自身のものに書き換えてください ::

    API_KEY = 'your_api_key'
    SHARED_SECRET = 'your_shared_secret'

* sample01.pyを実行した際に得られるtokenの値を以下と書き換えてください ::

    TOKEN = 'your_token'

* sample03.pyを実行しリスト名とIDをメモしておいてください

* sample04.pyの以下の部分を実際のIDに書き換えてください ::

    LIST_ID = 'your list id'
  

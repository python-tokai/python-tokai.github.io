#!/usr/bin/env python
# -*- mode: python -*- -*- coding: utf-8 -*-
#
#  sample02.py - simple test for rtm api
#
#   Copyright (C) 2011 SAKODA, Sumiya <higebobo@gmail.com>
#

"""\
simple test for rtm api
"""

__author__ = "Sumiya Sakoda"
__version__ = "$Revision$"
__date__ = "$Date: 2011/01/31 08:32:13 $"

import os
import sys

from sample01 import API_KEY, SHARED_SECRET, TOKEN, API_URL, FORMAT, \
     DATA_DIR, RTMError, json, get_response

DEBUG = False

def test_echo(debug=DEBUG):
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.test.echo',
              'perms': 'delete',
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'echo.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))

    print response

def test_login(debug=DEBUG):
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.test.login',
              'perms': 'read',
              'auth_token': TOKEN,              
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'login.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))

    print response

def test_method(debug=DEBUG):
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.reflection.getMethods',
              'perms': 'read',
              'auth_token': TOKEN,              
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'method.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.lodas(get_response(**params))

    print response

def test_methodinfo(debug=DEBUG):
    # set parameters    
    params = {'api_key': API_KEY,
              'method': 'rtm.reflection.getMethodInfo',
              'perms': 'read',
              'auth_token': TOKEN,
              'method_name': 'rtm.lists.getList',
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'methodinfo.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))

    print response

def test_timeparse(text=None, debug=DEBUG):
    # set parameters
    params = {'api_key': API_KEY,
              'method': 'rtm.time.parse',
              'perms': 'read',
              'auth_token': TOKEN,
              'format': FORMAT}
    if text:
        params['text'] = text
        print text

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'timeparse.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(**params))

    print response
    
def main():
    test_echo()

if __name__ == "__main__":
    if len(sys.argv) >= 2:
        arg = sys.argv[1]
        if arg == 'echo':
            test_echo()
        elif arg == 'login':
            test_login()
        elif arg == 'method':
            test_method()
        elif arg == 'methodinfo':
            test_methodinfo()
        elif arg == 'timeparse':
            if len(sys.argv) == 3:
                text = sys.argv[2]
            else:
                text = None
            test_timeparse(text)
        else:
            main()
    else:
        main()

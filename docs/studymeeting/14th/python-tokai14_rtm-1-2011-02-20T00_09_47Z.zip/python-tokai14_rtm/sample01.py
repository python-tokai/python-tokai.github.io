#!/usr/bin/env python
# -*- mode: python -*- -*- coding: utf-8 -*-
#
#  sample01.py - getting frob and token for rtm api
#
#   Copyright (C) 2011 SAKODA, Sumiya <higebobo@gmail.com>
#

"""\
gettig frob and token for rtm api

NOTE: require browser access environment (for example firefox).
"""

__author__ = "Sumiya Sakoda"
__version__ = "$Revision$"
__date__ = "$Date: 2011/01/31 08:32:13 $"

import os
import sys
import time
import urllib
import webbrowser

try:
    from hashlib import md5
except ImportError:
    from md5 import md5
try:
    import json
except ImportError:
    import simplejson as json

DEBUG = False
FORMAT = 'json'
DATA_DIR = 'data'

API_KEY = 'your_api_key'
SHARED_SECRET = 'your_shared_secret'
TOKEN = 'your_token'

API_URL = 'http://api.rememberthemilk.com/services/rest/'
AUTH_URL = 'http://www.rememberthemilk.com/services/auth/'

class RTMError(Exception):
    '''RTM Error'''
    
    def __init__(self, value):
        self.value = value

    def __str(self):
        return repr(self.value)

def _make_signature(**params):
    '''make api signature for rtm api'''
    
    # sort parameters by key and concat them with key and value
    sorted_params = [k + params[k] for k in sorted(params.keys())]
    
    # insert shared secret into joined parameters
    data = SHARED_SECRET + ''.join(sorted_params)
    
    # generate md5 hash
    signature = md5(data).hexdigest()
    
    return signature

def _make_request_url(request_url, **params):
    '''make request url for rpm api'''
    
    return '%s?%s' % (request_url, urllib.urlencode(params))

def get_response(request_url=API_URL, **params):
    '''get response method'''
    
    # generate api signature
    api_sig = _make_signature(**params)

    # add api signature into parameters
    params['api_sig'] = api_sig

    # make request url for getting response
    _request_url = _make_request_url(request_url, **params)

    # get response
    response = urllib.urlopen(_request_url).read()

    return response
    
def get_frob(debug=False):
    '''get frob method'''
    
    # set parameters
    params = {'api_key': API_KEY,
              'method': 'rtm.auth.getFrob',
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'frob.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(request_url=API_URL, **params))

    # parse json and return result
    if response['rsp']['stat'] == 'ok':
        return response['rsp']['frob']
    else:
        raise RTMError('Failed to get frob')

def get_token(frob, debug=False, **params):
    '''get token method'''
    
    # -*-*-*-  [part 1] authorization -*-*-*-
    # set parameters
    params = {'api_key': API_KEY,
              'frob': frob,
              'perms': 'delete'}

    # generate api signature
    api_sig = _make_signature(**params)

    # add api signature into parameters
    params['api_sig'] = api_sig

    # make request url for authorization
    auth_url = _make_request_url(AUTH_URL, **params)

    # access auth url by web browser
    if not debug:
        webbrowser.open_new(auth_url)
        time.sleep(5)


    # -*-*-*-  [part 2] get token -*-*-*-
    # set parameters
    params = {'api_key': API_KEY,
              'frob': frob,
              'format': FORMAT,
              'method': 'rtm.auth.getToken'}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'token.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(request_url=API_URL, **params))

    # parse json and return result
    if response['rsp']['stat'] == 'ok':
        return response['rsp']['auth']['token']
    else:
        raise RTMError('Failed to get token')

def check_token(debug=DEBUG):
    '''check token method'''
    
    # set parameters
    params = {'api_key': API_KEY,
              'method': 'rtm.auth.checkToken',
              'perms': 'delete',
              'auth_token': TOKEN,
              'format': FORMAT}

    # get response
    if DEBUG:
        fp = open(os.path.join(DATA_DIR, 'token_check.json'), 'r')
        response = json.loads(fp.read())
        fp.close()
    else:
        response = json.loads(get_response(request_url=API_URL, **params))

    # parse json and return result
    if response['rsp']['stat'] == 'ok':
        return response['rsp']['auth']['token']
    else:
        raise RTMError('Failed to check token')
    
def main():
    frob = get_frob(debug=DEBUG)
    #print 'your frob is ->', frob
    token = get_token(frob=frob, debug=DEBUG)
    print 'your token is ->', token
    #token_check = check_token(debug=DEBUG)
    #print 'your checked_token is ->', token_check

if __name__ == "__main__":
    main()

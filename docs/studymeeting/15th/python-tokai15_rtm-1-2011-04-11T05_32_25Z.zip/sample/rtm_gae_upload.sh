#!/bin/sh

gae_home=your_gae_dir
app_dir=rtm_gae
email=your_gmail_account@gmail

if [ -x /usr/bin/python26 ]; then
  cmd=/usr/bin/python26
elif [ -x /usr/bin/python25 ]; then
  cmd=/usr/bin/python26
else
  cmd=`which python`
fi

${cmd} ${gae_home}/appcfg.py --email=${email} update ${app_dir} 

#!/bin/sh

gae_home=your_gae_dir
app_dir=rtm_gae
smtp_host=smtp.gmail.com
smtp_user=your_gmail_account@gmail
smtp_password=your_gmail_password

if [ -x /usr/bin/python26 ]; then
  cmd=/usr/bin/python26
elif [ -x /usr/bin/python25 ]; then
  cmd=/usr/bin/python26
else
  cmd=`which python`
fi

${cmd} ${gae_home}/dev_appserver.py ${app_dir} \
    --smtp_host=${smtp_host} \
    --smtp_user=${smtp_user} \
    --smtp_password=${smtp_password}

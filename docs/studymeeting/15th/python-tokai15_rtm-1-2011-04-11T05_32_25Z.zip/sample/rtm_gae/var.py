API_KEY = "your_api_key"
SHARED_SECRET = "your_shared_secret"
TOKEN = "your_token"

RECIPIENT_PC = 'your_pc@example.com'
RECIPIENT_MOBILE = 'your_mobile@example.com'
SENDER = 'your_gmail_account@gmail.com'

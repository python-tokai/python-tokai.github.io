#!/usr/bin/env python
# -*- mode: python -*- -*- coding: utf-8 -*-
import datetime
import time

from google.appengine.ext.webapp.util import run_wsgi_app
from google.appengine.ext import webapp
from google.appengine.api import mail
try:
    from google.appengine import myconfig
    IS_DEV_SERVER = True
    SUBJECT_SUFFIX = u'(開発サーバ)'
except ImportError:
    IS_DEV_SERVER = False
    SUBJECT_SUFFIX = ''

import rtm
from var import RECIPIENT_PC, RECIPIENT_MOBILE, SENDER

def format_date(date, format='%Y-%m-%dT%H:%M:%SZ'):
    try:
        try:
            dateobj = datetime.datetime.strptime(date, format)
        except AttributeError:
            dateobj = datetime.datetime(*time.strptime(date, format)[:6])
        
        return dateobj + datetime.timedelta(hours=9)
    except:
        return date

class Reminder(webapp.RequestHandler):
    '''Common Reminder Class'''
    
    def __init__(self, sender=SENDER, recipient=RECIPIENT_PC,
                 subject='my task', task_filter='status:incomplete'):
        self.sender = sender
        self.recipient = recipient
        self.task = subject
        self.task_filter = task_filter
        
    def get(self):
        self.response.headers['Content-Type'] = 'text/html'
        tasks = rtm.get_task(self.task_filter)
        body = '\n'.join(('* %s - %s' % (str(format_date(x['due']))[5:16], x['name']) for x in tasks))
        if tasks:
            if IS_DEV_SERVER:
                subject = (self.subject+SUBJECT_SUFFIX).encode('iso-2022-jp')
                body = body.encode('iso-2022-jp')
            else:
                subject = self.subject
            mail.send_mail(sender=self.sender, to=self.recipient,
                           subject=subject, body=body)
            status = u'を送信しました'
        else:
            status = u'のタスクはありません'
        output = u'''\
<html>
<head><title>俺樣リマインダー</title></head>
<body>
<h1>%s%s</h1>
</body>
</html>''' % (self.subject, status)
        self.response.out.write(output)

class DailyReminder(Reminder):
    '''Daily Reminder Class'''

    def __init__(self):
        Reminder.__init__(self)
        self.recipient = RECIPIENT_MOBILE
        self.subject = u'明日の予定'
        self.task_filter = 'status:incomplete AND due:"tommorow"'

class DailyImportantReminder(Reminder):
    '''Daily Important Reminder Class'''

    def __init__(self):
        Reminder.__init__(self)
        self.subject = u'明日の予定(重要)'
        self.task_filter = 'status:incomplete AND (priority:1 OR list:"出勤時刻") AND dueWithin:"1 day of today"'

class WeeklyReminder(Reminder):
    '''Weekly Reminder Class'''

    def __init__(self):
        Reminder.__init__(self)
        self.subject = u'直近の予定'
        self.task_filter = 'status:incomplete AND ((NOT list:"出勤時刻" AND dueWithin:"2 weeks of today") OR (list:"出勤時刻" AND dueWithin:"1 week of today")'

class MonthlyReminder(Reminder):
    '''Monthly Reminder Class'''

    def __init__(self):
        Reminder.__init__(self)
        self.subject = u'今後の予定'
        self.task_filter = 'status:incomplete AND NOT list:"出勤時刻" AND dueWithin:"6 months of today"'

urls = [
    ('/cron/daily/', DailyReminder),
    ('/cron/dailyimportant/', DailyImportantReminder),
    ('/cron/weekly/', WeeklyReminder),
    ('/cron/monthly/', MonthlyReminder),
    ]

application = webapp.WSGIApplication(urls, debug=True)

def main():
    run_wsgi_app(application)

if __name__ == "__main__":
    main()
#### gae.py ends here

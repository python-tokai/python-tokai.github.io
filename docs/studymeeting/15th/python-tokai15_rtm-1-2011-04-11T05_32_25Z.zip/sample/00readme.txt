.. -*- mode: rst -*- coding: utf-8 -*-

============================
Python東海第１５回勉強会資料
============================

前準備
======

Google App Engine(gae)の開発サーバでメール送信を行う場合、
若干ソースの修正が必要となります。

これはgaeのバージョン、あるいはご使用のコンピュータの環境によっては
変わる場合がありますのでご了承下さい。

starttls
--------

gmailはstarttlsの使用が前提となっています。

patch/mail_stub.py.diff ::

  --- google/appengine/api/mail_stub.py.org	2010-12-16 08:06:19.000000000 +0900
  +++ google/appengine/api/mail_stub.py	2011-04-11 08:05:04.000000000 +0900
  @@ -134,6 +134,7 @@
       try:
         smtp.connect(self._smtp_host, self._smtp_port)
         if self._smtp_user:
  +        smtp.starttls()
           smtp.login(self._smtp_user, self._smtp_password)
   
         tos = ', '.join([mime_message[to] for to in ['To', 'Cc', 'Bcc']

文字コード
----------

開発サーバでは明示的にエンコードする必要があります。

patch/mail.py.diff ::

  --- google/appengine/api/mail.py.org	2010-12-16 08:06:19.000000000 +0900
  +++ google/appengine/api/mail.py	2011-04-05 13:10:51.000000000 +0900
  @@ -328,7 +328,7 @@
     return mime_type
   
   
  -def mail_message_to_mime_message(protocol_message):
  +def mail_message_to_mime_message(protocol_message, encoding='iso-2022-jp'):
     """Generate a MIMEMultitype message from protocol buffer.
   
     Generates a complete MIME multi-part email object from a MailMessage
  @@ -349,7 +349,7 @@
     """
     parts = []
     if protocol_message.has_textbody():
  -    parts.append(MIMEText.MIMEText(protocol_message.textbody()))
  +    parts.append(MIMEText.MIMEText(protocol_message.textbody(), 'plain', encoding))
     if protocol_message.has_htmlbody():
       parts.append(MIMEText.MIMEText(protocol_message.htmlbody(),
                                      _subtype='html'))


本番環境と開発サーバの識別
--------------------------

具体的な識別方法がわからなかったので以下の空のファイルを作成し、
そのimportの可否で識別するようにしました。

google/appengine/myconfig.py ::

  try:
      from google.appengine import myconfig
      IS_DEV_SERVER = True
  except ImportError:
      IS_DEV_SERVER = False

  if IS_DEV_SERVER:
      (開発サーバでの処理)
  else:
      (本番環境での処理)


スクリプトの変数
----------------

各スクリプト内の以下変数はご自身の環境に合わせてください。

rtm_gae.sh ::

  gae_home=gaeをインストールしたディレクトリ
  smtp_user=gmailのアカウント
  smtp_password=gmailのパスワード

rtm_gae_upload.sh ::

  gae_home=gaeをインストールしたディレクトリ
  email=gmailのアカウント

rtm_gae/var.py [#]_ ::

  API_KEY = 取得したapi key
  SHARED_SECRET = 取得したshared secret
  TOKEN = 取得したtoken

  RECIPIENT_PC = メールアドレス
  RECIPIENT_MOBILE = 携帯メールアドレス
  SENDER = gmailのアカウント

rtm_gae/app.yaml ::

  application: アプリケーション名

.. [#] tokenの取得についてはPython東海第14回勉強会資料参照 https://sites.google.com/site/pythontokai/14th/python-tokai14_rtm.zip

使い方
======

開発サーバでの実行 ::

  $ ./rtm_gae.sh
  $ w3m http://localhost:8080

デプロイ ::

  $ ./rtm_gae_upload.sh
